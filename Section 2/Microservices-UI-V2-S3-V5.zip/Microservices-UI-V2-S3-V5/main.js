var http = require('http'),
    fs = require('fs');
var url = require('url');


http.createServer(function (request, response) {
    var pathname=url.parse(request.url).pathname;
    switch(pathname){
        case '/chat': fs.readFile('./chat.html', function (err, html) {
            if (err) {
                throw err;
            }
            response.writeHeader(200, { "Content-Type": "text/html" });
            response.write(html);
            response.end();
        });
        break;
        default: fs.readFile('./index.html', function (err, html) {
            if (err) {
                throw err;
            }
            response.writeHeader(200, { "Content-Type": "text/html" });
            response.write(html);
            response.end();
        });
        break; 
    }  
}).listen(4000);
console.log("listening on localhost:4000");